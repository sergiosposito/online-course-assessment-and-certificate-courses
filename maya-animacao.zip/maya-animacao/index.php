<?php
	$titulo = 'Curso Gratis - Maya Animação';
	include '../../head.php';
?>
<link   rel="stylesheet" href="assets/css/style.css" />	
	
 

<header class="header role-element leadstyle-container">
        <div class="header-wrapper" data-lead-id="header-wrapper-id">
            <div class="logo" data-lead-id="logo-id">
              <?php include '../../logo.php'; ?>
            </div>
            <div class="desc-wrapper role-element leadstyle-container">
                <div class="headline" data-lead-id="headline-id">
                    <p class="headline__title role-element leadstyle-text">Maya Animação </p>
                        <span class="headline__course" data-lead-id="course-progress-visible-id">
                            <p class="role-element leadstyle-text">PART</p>
                            <p class="start num role-element leadstyle-dynamic">1</p>
                            <p class="role-element leadstyle-text">DE</p>
                            <p class="end num role-element leadstyle-dynamic">7</p>
                        </span>
                </div>
            </div>
        </div>
    </header>

	<section class="mb-5 ">
		<div class="bg-thumb">
				<div class="container">
					<h1 class="text-center text-white  display-3">Maya Animação de Personagem</h1>
					<h2 class="text-center lead text-white">Video Aula de Maya para Iniciantes em Animação Nesta video aula, você aprenderá a começar uma animação.</h2>
				
				
				
				 

   <div class="container">
		<div id="example-basic">
			  <h3 class="btn btn-primary"> Interface</h3>			
				<section>
					<iframe width="100%" height="421" src="https://www.youtube.com/embed/vLn6dWbQ8aI" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>	
				</section>
				
			 <h3  class="btn btn-primary"> Navegação de Interface e Manipulação de Objetos </h3>
				<section>
						<iframe width="100%" height="421" src="https://www.youtube.com/embed/5sztbSxpLfQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>	
				</section>
				
			 <h3  class="btn btn-primary">Preferencias, Ferramentas e Manipulação de Objetos</h3>
			<section>
						<iframe width="100%" height="421" src="https://www.youtube.com/embed/15i81rEb2T4" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>	
			</section>       

			 <h3  class="btn btn-primary"> Animação Aula 01 </h3>
			<section>
					<iframe width="100%" height="421" src="https://www.youtube.com/embed/iiqRquG_1gE" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>	
			</section>		

			 <h3  class="btn btn-primary">  Animação Aula 02 </h3>
			<section>
					<iframe width="100%" height="421" src="https://www.youtube.com/embed/MLIyw54EOZE" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>	
			</section>			
			
			 <h3  class="btn btn-primary"> Animação Aula 03 </h3>
			<section>
					<iframe width="100%" height="421" src="https://www.youtube.com/embed/V6GZp_aAglM" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>	
			</section>			
			
			 <h3  class="btn btn-primary"> Animação Aula Rendering </h3>
			<section>
					<iframe width="100%" height="421" src="https://www.youtube.com/embed/hbWMs6GAgfo" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>	
			</section>	
  
			<h3 class="btn btn-primary">Avaliação</h3>
				<section style="overflow-y: scroll;">
					<form  action='controller/salvaQuestionarioController.php' method='post'>
							 <div class="form-group">
								<input class="form-control" type="text" name="nome_aluno" id="name" value="A">
							 </div>
							
							 <div class="form-group">							 
								<input class="form-control" type="text" name="email" id="email" value="A">
							  </div>
							  
							<div class="questao-1">
							   <p>1 O Maya é um software da linha:</p>
							   <div class="form-check">
								  <input class="form-check-input" type="radio" name="questao1" id="questao1" value="A">
								  <label class="form-check-label" for="exampleRadios1">
									A) Técnica
								  </label>
								</div>		

								<div class="form-check">
								  <input class="form-check-input" type="radio" name="questao1" id="questao1" value="B">
								  <label class="form-check-label" for="exampleRadios1">
									B) Artística
								  </label>
								</div>	

								<div class="form-check">
								  <input class="form-check-input" type="radio" name="questao1" id="questao1" value="C">
								  <label class="form-check-label" for="exampleRadios1">
									C) Construção 
								  </label>
								</div>			
 
							</div>			

							<hr></hr>
							
							<div class="questao-2">
								<p>2 Quando um objeto esta selecionado no Maya ele destaca esse objeto com uma cor. Qual a cor padrão de seleção de um objeto?</p>
							   <div class="form-check">
								  <input class="form-check-input" type="radio" name="questao2" id="questao2" value="A">
								  <label class="form-check-label" for="exampleRadios1">
									A) Azul
								  </label>
								</div>		

								<div class="form-check">
								  <input class="form-check-input" type="radio" name="questao2" id="questao2" value="B">
								  <label class="form-check-label" for="exampleRadios1">
									B) Branco
								  </label>
								</div>	

								<div class="form-check">
								  <input class="form-check-input" type="radio" name="questao2" id="questao2" value="C">
								  <label class="form-check-label" for="exampleRadios1">
									C) Verde 
								  </label>
								</div>			

								 
							</div>	
					
							<hr> </hr>
							<div class="questao-3">
							   <p>3 Em qual menu encontra-se a opção Center Pivot?</p>
							   <div class="form-check">
								  <input class="form-check-input" type="radio" name="questao3" id="questao3" value="A"  >
								  <label class="form-check-label" for="exampleRadios1">
									A) Edit
								  </label>
								</div>		

								<div class="form-check">
								  <input class="form-check-input" type="radio" name="questao3" id="questao3" value="B"  >
								  <label class="form-check-label" for="exampleRadios1">
									B) Object
								  </label>
								</div>	

								<div class="form-check">
								  <input class="form-check-input" type="radio" name="questao3" id="questao3" value="C"  >
								  <label class="form-check-label" for="exampleRadios1">
									C) Modify 
								  </label>
								</div>			

								 
							</div>		

					<hr></hr>

							<div class="questao-4">
							   <p>4 Em uma tarefa de criação de animação, podemos dizer que o Maya é:</p>
							   <div class="form-check">
								  <input class="form-check-input" type="radio" name="questao4" id="questao4" value="A"  >
								  <label class="form-check-label" for="exampleRadios1">
									A) Animador Mestre
								  </label>
								</div>		

								<div class="form-check">
								  <input class="form-check-input" type="radio" name="questao[4]" id="questao4" value="B"  >
								  <label class="form-check-label" for="exampleRadios1">
									B) Animador Assistente 
								  </label>
								</div>	

								<div class="form-check">
								  <input class="form-check-input" type="radio" name="questao4" id="questao4" value="C"  >
								  <label class="form-check-label" for="exampleRadios1">
									C) Animador Senior
								  </label>
								</div>			
 
							</div>			

							<div class="questao-5">
							   <p>5 Qual a diferença entre Set Key e Auto Key?</p>
							   <div class="form-check">
								  <input class="form-check-input" type="radio" name="questao5" id="questao5" value="A"  >
								  <label class="form-check-label" for="exampleRadios1">
									A) O Set Key grava Automaticamente os keyframes e o Auto Key grava manualmente.
								  </label>
								</div>		

								<div class="form-check">
								  <input class="form-check-input" type="radio" name="questao5" id="questao5" value="B"  >
								  <label class="form-check-label" for="exampleRadios1">
									B) O Set Key grava manualmente os keyframes e o Auto Key grava Automaticamente. 
								  </label>
								</div>	

								<div class="form-check">
								  <input class="form-check-input" type="radio" name="questao5" id="questao5" value="C"  >
								  <label class="form-check-label" for="exampleRadios1">
									C) Não existe diferença entre os dois comandos.
								  </label>
								</div>			

							 
							</div>		

							<div class="questao-6">
							   <p>6 O painel do Graph Editor pode ser acessado através de qual menu:</p>
							   <div class="form-check">
								  <input class="form-check-input" type="radio" name="questao6" id="questao6" value="A"  >
								  <label class="form-check-label" for="exampleRadios1">
									A) Display / Graph Editor
								  </label>
								</div>		

								<div class="form-check">
								  <input class="form-check-input" type="radio" name="questao6" id="questao6" value="B"  >
								  <label class="form-check-label" for="exampleRadios1">
									B) Window / Graph Editor
								  </label>
								</div>	

								<div class="form-check">
								  <input class="form-check-input" type="radio" name="questao6" id="questao6" value="C"  >
								  <label class="form-check-label" for="exampleRadios1">
									C) Window / Animation Editor / Graph Editor
								  </label>
								</div>			

								  
							</div>			

							<div class="questao-7">
							   <p>7 No processo de configuração do rendering ao se escolher a opção name#.ext em Frame/Animation ext, o que significa?</p>
							   <div class="form-check">
								  <input class="form-check-input" type="radio" name="questao7" id="questao7" value="A"  >
								  <label class="form-check-label" for="exampleRadios1">
									 A) Significa que o Maya vai gerar um vídeo QuickTime numerado em sequência.
								  </label>
								</div>		

								<div class="form-check">
								  <input class="form-check-input" type="radio" name="questao7" id="questao7" value="B"  >
								  <label class="form-check-label" for="exampleRadios1">
									B) Significa que o Maya vai gerar imagens numeradas em sequência. (correta)
								  </label>
								</div>	
 
								<div class="form-check">
								  <input class="form-check-input" type="radio" name="questao7" id="questao7" value="C"  >
								  <label class="form-check-label" for="exampleRadios1">
									C) Significa que o Maya vai gerar imagens numeradas em sequência aleatórias.
								  </label>
								</div>			

								 
							</div>
					
						<input type="submit" value="Enviar" class="btn btn-danger">
					</form>
				</section>
			</div>
		</div>
	</div>
</div>
				<div class="row justify-content-center">
					<div class="mt-4 download-btn" data-lead-id="download-btn-id">
						<a id="optin-button" class="optin-link role-element leadstyle-link" href="https://www.animationmentor.com/workshops/maya-workshop-animation-basics/" target="_blank">CONHEÇA O CURSO LOCOMOTION ANIMAÇÃO DE PERSONAGEM</a>
					</div>
				</div> 

				
	</section>
 

	<section class="section fp-auto-height footer">
		<footer class="fp-tableCell w-100 d-block">
				<div style="background: #111;border-radius: 0;" class="card text-center">
					<div class="mt-1 mb-1 card-body">
						<h5 class="card-title">
							<div class="redes">
								<!-- Facebook -->
								<ul class="list-inline">
									<li class="list-inline-item">
										<a href="https://www.facebook.com/havokcg/" target="_blank" class="fb-ic">
										<i class="fab fa-facebook white-text mr-2"> </i>
										</a>
									</li>
									<!-- Twitter -->
									<li class="list-inline-item">
										<a href="https://twitter.com/viahavok" target="_blank" class="tw-ic">
										<i class="fab fa-twitter white-text mr-2"> </i>
										</a>
									</li>
									<!-- Google +-->
									<li class="list-inline-item">
										<a href="https://plus.google.com/103016090068125193699" target="_blank" class="gplus-ic">
										<i class="fab fa-google-plus white-text mr-2"> </i>
										</a>
									</li>
									<!--Linkedin -->
									<li class="list-inline-item">
										<a href="https://www.linkedin.com/company/via-havok-escola-de-3d-e-games/?originalSubdomain=pt" target="_blank" class="li-ic">
										<i class="fab fa-linkedin white-text mr-2"> </i>
										</a>
									</li>
									<!--Instagram-->
									<li class="list-inline-item">
										<a href="https://www.instagram.com/havokcg/?hl=pt-br" target="_blank" class="ins-ic">
										<i class="fab fa-instagram white-text mr-2"> </i>
										</a>
									</li>
									<li class="list-inline-item">
										<a target="_blank" title="Mande-nos uma mensagem no Whatsapp!" href="https://api.whatsapp.com/send?l=pt_BR&amp;phone=5511992637761" class="ins-ic">
										<i class="fab fa-whatsapp mr-2"></i>
										</a>
									</li>
									<li class="list-inline-item">
										<a target="_blank" href="https://br.pinterest.com/viahavok/overview/" class="ins-ic">
										<i class="fab fa-pinterest"></i>
										</a>
									</li>
								</ul>
							</div>
						</h5>
						<p class="text-white card-text"> HAVOK SCHOOL  -  Rua. Frei Caneca, 558 - 23ºAndar Consolação - São Paulo - SP</p>
					</div>
					<div class="text-white card-footer text-muted">
						© 2019 HAVOK SCHOOL - Todos os direitos reservados.
					</div>
				</div>
			</footer>
		</section>
	</div>
</div>

	<!--Start of Tawk.to Script-->
	<script type="text/javascript">
	var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
	(function(){
	var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
	s1.async=true;
	s1.src='https://embed.tawk.to/5c742b443341d22d9ce60587/default';
	s1.charset='UTF-8';
	s1.setAttribute('crossorigin','*');
	s0.parentNode.insertBefore(s1,s0);
	})();
	</script>	
	
	
	
	
	<!--End of Tawk.to Script-->
	
	<link rel="stylesheet" async href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
	<link media="screen and (min-width: 900px)"  rel="stylesheet" href="https://havokschool.com.br/assets/css/jquery.fullpage.min.css" />	
	<script type="text/javascript"  src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script> 
	<script type="text/javascript" src="https://code.jquery.com/jquery-migrate-1.2.1.min.js"></script> 
	<script type="text/javascript" src="https://havokschool.com.br/assets/js/bootstrap.min.js"></script>
	<script type="text/javascript"  src="assets/css/jquery.steps-1.1.0/jquery.steps.js"></script>
	
	<script type="text/javascript">
	

		$("#example-basic").steps({
			headerTag: "h3",
			bodyTag: "section",
			transitionEffect: "slideLeft",
			autoFocus: true,
			enableAllSteps: true,
			enablePagination: false
		});


	</script>
	
	
	</body>
	
</html>