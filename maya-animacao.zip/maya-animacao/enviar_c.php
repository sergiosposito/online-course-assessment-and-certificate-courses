<?php

	require_once 'model/salvaQuestionario.php'; 
	$obj = new SalvaQuestionario();
	
	foreach($obj->exibeResultado() as $rst){
	 
	$total = 7;	
	$valor_descontado = ($rst['TOTAL_ALUNO'] / $total *  100);
 
  
	if($valor_descontado >= 100){
		$erro = ($total - $rst['TOTAL_ALUNO']);
		
		// Enviar E-mail
		
		$headers = "MIME-Version: 1.1\r\n";
	 
		$headers .= "From: ". $email ."\r\n";
		$headers .= "Return-Path:". $email ."\r\n";
		 
		$nome = $_POST['nome'];
		$celular = $_POST['celular'];
		$telefone = $_POST['telefone'];
		$msg = $_POST['mensagem'];
		$curso = $_POST['curso'];

		$conteudo="Aprovado - Nome: " .$rst['nome_aluno']. "\n E-mail: " .$rst['email'];
		$recebedor = "sergio@havokschool.com.br";
		$titulo = "Curso Gratis Maya Animação";
	?>
 
	<div style="background:url(assets/img/img-l.png);width: 1800px;height: 1294px;">
		<p style="position: absolute;font-size: 56px;margin-top: 379px;font-family: Lato;color: #fff;margin-left: 1014px;width: 640px;text-transform: uppercase;font-weight: bold;">
			<?=$rst['nome_aluno']?>
		</p>
		
		<p style="position: absolute;font-size: 47px;margin-top: 976px;font-family: Lato;color: #fff;margin-left: 1016px;width: 640px;text-transform: uppercase;font-weight: bold;">
			<?php echo date("d/m/Y"); ?>
		</p>	

		<p style="position: absolute;font-size: 44px;margin-top: 901px;font-family: Lato;color: #fff;margin-left: 936px;width: 640px;text-transform: uppercase;font-weight: bold;">
			<?php echo date("Y"); ?>
		</p>
	</div>
	
	<?
	$envio = mail($recebedor , $titulo, $conteudo, $headers) or die ("Erro!");
	
	 
} 
else{ 

	$headers = "MIME-Version: 1.1\r\n";
 
	$headers .= "From: ". $email ."\r\n";
	$headers .= "Return-Path:". $email ."\r\n";
	 
	
	$nome = $_POST['nome'];
	$celular = $_POST['celular'];
	$telefone = $_POST['telefone'];
	$msg = $_POST['mensagem'];
	$curso = $_POST['curso'];

	$conteudo="REPROVADO - Nome: " .$rst['nome_aluno']. "\n E-mail: " .$rst['email'];
	$recebedor = "sergio@havokschool.com.br";
	$titulo = "Curso Gratis Maya Animação";
	
	$envio = mail($recebedor , $titulo, $conteudo, $headers) or die ("Erro!");
 
    $erro = ($total - $rst['TOTAL_ALUNO']);
	 
}
}

?>